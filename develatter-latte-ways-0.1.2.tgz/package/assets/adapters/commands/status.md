---
description: Show the active harness work, mode and phase
---
Run `npx ways status --json` and summarise mode, id, phase, profile and whether a human gate is pending. If nothing is active, say so and list the ways to open work: {{command:quick}}, {{command:plan}}, {{command:sdd}}. Closing, cancelling and advancing are done by you through the CLI, never by the human.
